#!/bin/bash
# Setup script to run on PACE cluster

set -e

echo "Setting up AlphaChicken on PACE..."

# Check if we need to compile the library
if [ ! -f "3600-agents/CPPHikaru_3/libcpphikaru3.so" ]; then
    echo "Compiling C++ library..."
    cd 3600-agents/CPPHikaru_3
    
    # On Linux (PACE), use Makefile directly - no Docker needed
    if [ -f "Makefile" ]; then
        echo "  Using Makefile to compile..."
        make clean
        make
        echo "  ✓ Library compiled successfully"
    else
        echo "ERROR: No Makefile found!"
        exit 1
    fi
    cd ../..
else
    echo "  ✓ Library already exists"
fi

# Set library path
export LD_LIBRARY_PATH="${PWD}/3600-agents/CPPHikaru_3:${LD_LIBRARY_PATH}"

echo ""
echo "Setup complete!"
echo ""
echo "To run batch games:"
echo "  ./run_batch_games.sh Hikaru_3 100"
echo ""
