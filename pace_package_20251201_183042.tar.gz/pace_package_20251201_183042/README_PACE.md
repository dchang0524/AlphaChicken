# PACE Deployment Package

## Quick Start

1. **Extract the package:**
   ```bash
   tar -xzf pace_package_*.tar.gz
   cd pace_package_*
   ```

2. **Run setup:**
   ```bash
   bash setup_on_pace.sh
   ```
   This will compile the C++ library if needed.

3. **Run batch games:**
   ```bash
   ./run_batch_games.sh Hikaru_3 100
   ```

## What's Included

- `CPPHikaru_3/` - Your C++ agent (source + compiled library if available)
- `Hikaru_3/` - Opponent agent for testing
- `engine/` - Game engine code
- `run_batch_games.sh` - Batch runner script
- `requirements.txt` - Python dependencies

## Dependencies

Make sure Python 3 and a C++ compiler (g++) are available on PACE.
The requirements.txt lists Python packages needed.

## Batch Testing

The batch script will:
- Run games in parallel
- Track search depth by move range
- Generate detailed statistics

Results are saved in `batch_results_TIMESTAMP/` directory.
