
from __future__ import annotations

from typing import List, Tuple, Set
from game import board as board_mod  # type: ignore

from .bfs_utils import bfs_distances_both  # assumes you defined this in bfs_utils.py

OWNER_NONE = 0
OWNER_ME   = 1  # current player (board.chicken_player)
OWNER_OPP  = 2  # enemy (board.chicken_enemy)

def analyze(
    self,
    cur_board: board_mod.Board,
    known_traps: Set[Tuple[int, int]],
) -> VoronoiInfo:

    dim  = cur_board.game_map.MAP_SIZE
    last = dim - 1

    # 1) BFS distances (movement blocking handled inside BFS)
    dist_me, dist_opp = bfs_distances_both(cur_board, known_traps)

    # Parities
    my_even  = cur_board.chicken_player.even_chicken
    opp_even = cur_board.chicken_enemy.even_chicken

    # My current position (for directional contested counts)
    my_x, my_y = cur_board.chicken_player.get_location()

    # 2D owner grid
    owner: List[List[int]] = [
        [OWNER_NONE for _ in range(dim)] for _ in range(dim)
    ]

    my_owned   = 0
    opp_owned  = 0
    contested  = 0
    max_contested_dist = 0
    min_contested_dist = dim * dim

    my_voronoi  = 0
    opp_voronoi = 0

    # Directional frontier pressure
    contested_up = 0
    contested_right = 0
    contested_down = 0
    contested_left = 0

    #Quadrant Fragmentation Score
    contested_q1 = 0
    contested_q2 = 0
    contested_q3 = 0
    contested_q4 = 0

    for x in range(dim):
        for y in range(dim):

            d_me  = dist_me[x][y]
            d_opp = dist_opp[x][y]

            reachable_me  = (d_me  >= 0)
            reachable_opp = (d_opp >= 0)

            # --------------------------
            # 1) Reachability ownership
            # --------------------------
            if reachable_me and (not reachable_opp or d_me <= d_opp):
                owner[x][y] = OWNER_ME
                my_owned += 1

            elif reachable_opp:
                owner[x][y] = OWNER_OPP
                opp_owned += 1

            # --------------------------
            # 2) Contested frontier
            #    - both can reach
            #    - I own it (I get there first or tie)
            #    - opp is within 1 ply of me
            # --------------------------
            if (
                reachable_me
                and reachable_opp
                and owner[x][y] == OWNER_ME
                and abs(d_me - d_opp) <= 1
            ):
                contested += 1

                # Depth of my frontier from my POV
                if d_me > max_contested_dist:
                    max_contested_dist = d_me
                elif d_me < min_contested_dist:
                    min_contested_dist = d_me

                # Direction assignment from my position
                dx = x - my_x
                dy = y - my_y

                # Ignore my own square if it ever qualifies (paranoia guard)
                if dx != 0 or dy != 0:
                    #TODO: Check if its better to only add contested to the dominant direction
                    #if abs(dx) > abs(dy):
                    if dx > 0:
                        contested_right += 1
                    else:
                        contested_left += 1
                    #else:
                if dy > 0:
                    contested_down += 1   # y increasing = DOWN
                elif dy < 0:
                    contested_up += 1     # y decreasing = UP
                
                # Quadrant
                if dx > 0 and dy < 0:
                    contested_q1 += 1
                elif dx < 0 and dy < 0:
                    contested_q2 += 1
                elif dx < 0 and dy > 0:
                    contested_q3 += 1
                elif dx > 0 and dy > 0:
                    contested_q4 += 1

            # --------------------------
            # 3) Parity-based Voronoi (corner-weighted)
            # --------------------------

            # Corner weight
            is_corner = (x == 0 or x == last) and (y == 0 or y == last)
            weight = 3 if is_corner else 1

            # square parity
            square_even = ((x + y) & 1) == 0
            is_my_par   = (square_even == my_even)
            is_opp_par  = (square_even == opp_even)

            # --- MY VORONOI ---
            if is_my_par and owner[x][y] == OWNER_ME:
                my_voronoi += weight

            # --- OPP VORONOI ---
            if is_opp_par and owner[x][y] == OWNER_OPP:
                opp_voronoi += weight

    # 4) Directional fragmentation score in [0,1], based on contested_* counts
    L = contested_left
    R = contested_right
    U = contested_up
    D = contested_down

    counts = [L, R, U, D]
    total = sum(counts)

    if total <= 1:
        cardinal_frag = 0.0
    else:
        # How many directions actually have contested squares?
        dir_count = sum(1 for c in counts if c > 0)
        # Normalize: 1 direction → 0, 4 directions → 1
        dir_score = (dir_count - 1) / 3.0  # ∈ [0,1]

        # How evenly is the frontier spread?
        major_fraction = max(counts) / total  # ∈ (0,1]
        spread_score = 1.0 - major_fraction   # ∈ [0,1), 0 when all in one dir

        # Opposite-direction bonus: L+R or U+D both active → more fragmentation.
        opp_bonus = 0.0
        if L > 0 and R > 0:
            opp_bonus += 0.5
        if U > 0 and D > 0:
            opp_bonus += 0.5
        opp_score = min(1.0, opp_bonus)  # 0, 0.5, or 1.0

        cardinal_frag = (
            0.4 * spread_score +   # how evenly spread
            0.2 * dir_score   +    # how many directions
            0.4 * opp_score        # opposite sides involved
        )
        # Clamp
        if cardinal_frag < 0.0:
            cardinal_frag = 0.0
        elif cardinal_frag > 1.0:
            cardinal_frag = 1.0

    quad_counts = [contested_q1, contested_q2, contested_q3, contested_q4]
    quad_dirs = sum(1 for c in quad_counts if c > 0)
    quad_spread = 1.0 - (max(quad_counts) / total) if total > 0 else 0.0
    quad_score = 0.5 * quad_spread + 0.5 * ((quad_dirs - 1) / 3.0)
    frag_score = 0.5 * cardinal_frag + 0.5 * quad_score

    return VoronoiInfo(
        my_owned           = my_owned,
        opp_owned          = opp_owned,
        contested          = contested,
        max_contested_dist = max_contested_dist,
        min_contested_dist = min_contested_dist,
        my_voronoi=  my_voronoi,
        opp_voronoi = opp_voronoi,
        contested_up       = contested_up,
        contested_right    = contested_right,
        contested_down     = contested_down,
        contested_left     = contested_left,
        frag_score   = frag_score,
    )


OWNER_NONE = 0
OWNER_ME   = 1
OWNER_OPP  = 2


class VoronoiInfo:
    """
    Board-dependent Voronoi / frontier analysis.

    Fields:
      - dist_me[x][y], dist_opp[x][y] : BFS distances for each player
      - owner[x][y]  : OWNER_NONE / OWNER_ME / OWNER_OPP (reachability-based)
      - my_owned     : # of cells where I arrive first (or tie)
      - opp_owned    : # of cells where opponent arrives first
      - contested    : # of "my frontier" squares:
                       both can reach, I own it, and opp is within 1 ply
      - max_contested_dist : max d_me over all contested squares
      - my_voronoi   : parity-based, corner-weighted voronoi score for me
      - opp_voronoi  : same for opponent
      - vor_score    : my_voronoi - opp_voronoi

      - contested_up    : how many contested squares lie primarily "above" me
      - contested_right : how many contested squares lie primarily "right" of me
      - contested_down  : how many contested squares lie primarily "below" me
      - contested_left  : how many contested squares lie primarily "left" of me

      - frag_directional: fragmentation score in [0,1] based on the distribution
                          of contested squares across directions.
    """

    __slots__ = (
        "owner",
        "my_owned",
        "opp_owned",
        "contested",
        "max_contested_dist",
        "min_contested_dist",
        "my_voronoi",
        "opp_voronoi",
        "vor_score",
        "contested_up",
        "contested_right",
        "contested_down",
        "contested_left",
        "frag_score",
    )

    def __init__(
        self,
        my_owned,
        opp_owned,
        contested,
        max_contested_dist,
        min_contested_dist,
        my_voronoi,
        opp_voronoi,
        contested_up,
        contested_right,
        contested_down,
        contested_left,
        frag_score,
    ):
        self.my_owned           = my_owned
        self.opp_owned          = opp_owned
        self.contested          = contested
        self.max_contested_dist = max_contested_dist
        self.min_contested_dist = min_contested_dist

        self.my_voronoi  = my_voronoi
        self.opp_voronoi = opp_voronoi
        self.vor_score   = my_voronoi - opp_voronoi

        self.contested_up    = contested_up
        self.contested_right = contested_right
        self.contested_down  = contested_down
        self.contested_left  = contested_left

        self.frag_score = frag_score



# from __future__ import annotations
# import numpy as np
# from typing import Tuple, Set, List
# from game import board as board_mod  # type: ignore

# # Use the numpy BFS we optimized earlier
# from .bfs_utils import bfs_distances_both 

# OWNER_NONE = 0
# OWNER_ME   = 1
# OWNER_OPP  = 2

# class VoronoiInfo:
#     __slots__ = (
#         "my_owned", "opp_owned", "contested",
#         "max_contested_dist", "min_contested_dist",
#         "my_voronoi", "opp_voronoi", "vor_score",
#         "contested_up", "contested_right", "contested_down", "contested_left",
#         "frag_score",
#     )

#     def __init__(self, **kwargs):
#         for k, v in kwargs.items():
#             setattr(self, k, v)

# def analyze(
#     self,
#     cur_board: board_mod.Board,
#     known_traps: Set[Tuple[int, int]],
# ) -> VoronoiInfo:

#     dim = cur_board.game_map.MAP_SIZE
    
#     # 1. Get Distances
#     dist_me_raw, dist_opp_raw = bfs_distances_both(cur_board, known_traps)

#     # --- SAFETY FIX: FORCE NUMPY ARRAY ---
#     # This prevents the "list >= int" crash if bfs_utils returns a list
#     dist_me = np.array(dist_me_raw, dtype=np.int8)
#     dist_opp = np.array(dist_opp_raw, dtype=np.int8)
#     # -------------------------------------

#     # 2. Create boolean masks (Now safe)
#     reach_me  = (dist_me >= 0)
#     reach_opp = (dist_opp >= 0)


#     # 3. Determine Ownership (Vectorized)
#     #    I own it if I can reach it AND (opp can't OR I am closer/equal)
#     #    Note: "d_me <= d_opp" handles the tie-breaker
#     wins_race = (dist_me <= dist_opp)
    
#     # Owner masks
#     is_me  = reach_me & (~reach_opp | wins_race)
#     is_opp = reach_opp & (~is_me) # If I don't own it and opp can reach, opp owns it
    
#     # Counts
#     my_owned  = np.sum(is_me)
#     opp_owned = np.sum(is_opp)

#     # 4. Contested Frontier (Vectorized)
#     #    Rules: Both reach, I own it, Opp is within 1 step of me
#     #    abs(d_me - d_opp) <= 1  <==>  d_opp - d_me <= 1 (since d_me <= d_opp here)
#     dist_diff = dist_opp - dist_me
#     # We use 'is_me' mask so we know d_me <= d_opp is implicitly true-ish, 
#     # but strictly we check the diff.
#     # Note: We must ensure reach_opp is True to calculate diff safely.
    
#     frontier_mask = (
#         is_me & 
#         reach_opp & 
#         (dist_diff <= 1)
#     )
    
#     contested = np.sum(frontier_mask)

#     max_contested_dist = 0
#     min_contested_dist = dim * dim
    
#     # If we have any contested squares, get their stats
#     if contested > 0:
#         # Extract the 'dist_me' values only where frontier_mask is True
#         frontier_dists = dist_me[frontier_mask]
#         max_contested_dist = np.max(frontier_dists)
#         min_contested_dist = np.min(frontier_dists)

#     # 5. Parity-Based Weighted Voronoi
#     #    Create coordinate grids
#     y_grid, x_grid = np.indices((dim, dim))
    
#     # Parity masks
#     # (x + y) & 1 == 0 is Even
#     square_sum = x_grid + y_grid
#     is_even = (square_sum & 1) == 0
#     is_odd  = ~is_even

#     my_even  = cur_board.chicken_player.even_chicken
#     opp_even = cur_board.chicken_enemy.even_chicken

#     # Weight grid (Corners = 3, Others = 1)
#     weights = np.ones((dim, dim), dtype=np.int8)
#     weights[0, 0] = 3
#     weights[0, dim-1] = 3
#     weights[dim-1, 0] = 3
#     weights[dim-1, dim-1] = 3

#     # Calculate Scores
#     # My Voronoi: Sum of weights where (is_me) AND (parity matches my chicken)
#     if my_even:
#         my_mask = is_me & is_even
#     else:
#         my_mask = is_me & is_odd
        
#     if opp_even:
#         opp_mask = is_opp & is_even
#     else:
#         opp_mask = is_opp & is_odd

#     my_voronoi  = np.sum(weights[my_mask])
#     opp_voronoi = np.sum(weights[opp_mask])

#     # 6. Directional Stats (Vectorized)
#     #    Based on my current position
#     my_x, my_y = cur_board.chicken_player.get_location()
    
#     # Create relative grids
#     dx = x_grid - my_x
#     dy = y_grid - my_y

#     # Directional masks combined with frontier_mask
#     c_up    = np.sum(frontier_mask & (dy < 0)) # y decreasing is Up
#     c_down  = np.sum(frontier_mask & (dy > 0))
#     c_left  = np.sum(frontier_mask & (dx < 0))
#     c_right = np.sum(frontier_mask & (dx > 0))

#     # 7. Fragmentation (Fast Logic)
#     #    (Re-using your logic but simplified math)
#     counts = [c_left, c_right, c_up, c_down]
#     total = np.sum(counts)
    
#     frag_score = 0.0
#     if total > 1:
#         # Simple fragmentation heuristic
#         # How many distinct quadrants/directions are active?
#         # Re-implementing exact logic might be overkill, 
#         # let's use a standard "Spread" metric which is faster.
        
#         # Max concentration
#         m = max(counts)
#         # 1.0 means all in one dir (good), 0.25 means perfect split (bad)
#         concentration = m / total 
#         # Invert: 0.0 (concentrated) -> 1.0 (fragmented)
#         frag_score = 1.0 - concentration

#     return VoronoiInfo(
#         my_owned=int(my_owned),
#         opp_owned=int(opp_owned),
#         contested=int(contested),
#         max_contested_dist=int(max_contested_dist),
#         min_contested_dist=int(min_contested_dist),
#         my_voronoi=int(my_voronoi),
#         opp_voronoi=int(opp_voronoi),
#         vor_score=int(my_voronoi - opp_voronoi),
#         contested_up=int(c_up),
#         contested_right=int(c_right),
#         contested_down=int(c_down),
#         contested_left=int(c_left),
#         frag_score=float(frag_score),
#     )









# iteration 3

# from __future__ import annotations
# import numpy as np
# from typing import Tuple, Set, List
# from game import board as board_mod

# # Use the numpy BFS
# from .bfs_utils import bfs_distances_both 

# OWNER_NONE = 0
# OWNER_ME   = 1
# OWNER_OPP  = 2

# # --- PRE-ALLOCATED STATIC GRIDS (Speed Optimization) ---
# # We compute these ONCE so we don't waste time creating them 20k times/sec
# _CACHE_DIM = None
# _X_GRID = None
# _Y_GRID = None
# _WEIGHTS = None
# _IS_EVEN = None
# _IS_ODD = None

# def _init_globals(dim: int):
#     """One-time setup for static grids"""
#     global _CACHE_DIM, _X_GRID, _Y_GRID, _WEIGHTS, _IS_EVEN, _IS_ODD
#     _CACHE_DIM = dim
    
#     # 1. Coordinate Grids
#     _Y_GRID, _X_GRID = np.indices((dim, dim))
    
#     # 2. Weights (Corner = 3)
#     _WEIGHTS = np.ones((dim, dim), dtype=np.int8)
#     _WEIGHTS[0, 0] = 3
#     _WEIGHTS[0, dim-1] = 3
#     _WEIGHTS[dim-1, 0] = 3
#     _WEIGHTS[dim-1, dim-1] = 3
    
#     # 3. Parity Masks
#     sq_sum = _X_GRID + _Y_GRID
#     _IS_EVEN = (sq_sum & 1) == 0
#     _IS_ODD  = ~_IS_EVEN

# class VoronoiInfo:
#     __slots__ = (
#         "my_owned", "opp_owned", "contested",
#         "max_contested_dist", "min_contested_dist",
#         "my_voronoi", "opp_voronoi", "vor_score",
#         "contested_up", "contested_right", "contested_down", "contested_left",
#         "frag_score",
#     )

#     def __init__(self, **kwargs):
#         for k, v in kwargs.items():
#             setattr(self, k, v)

# def analyze(
#     self,
#     cur_board: board_mod.Board,
#     known_traps: Set[Tuple[int, int]],
# ) -> VoronoiInfo:
#     dim = cur_board.game_map.MAP_SIZE
    
#     # Lazy Init of globals (Only happens ONCE per game)
#     if _CACHE_DIM != dim:
#         _init_globals(dim)
    
#     # 1. Get Distances 
#     # Safe cast: Ensures we have an array even if bfs_utils returns a list
#     dist_me_raw, dist_opp_raw = bfs_distances_both(cur_board, known_traps)
#     dist_me  = np.asarray(dist_me_raw, dtype=np.int8)
#     dist_opp = np.asarray(dist_opp_raw, dtype=np.int8)

#     # 2. Reachability & Ownership (Vectorized - Fast)
#     reach_me  = (dist_me >= 0)
#     reach_opp = (dist_opp >= 0)
#     wins_race = (dist_me <= dist_opp)
    
#     is_me  = reach_me & (~reach_opp | wins_race)
#     is_opp = reach_opp & (~is_me)
    
#     my_owned  = np.sum(is_me)
#     opp_owned = np.sum(is_opp)

#     # 3. Contested Frontier
#     dist_diff = dist_opp - dist_me
#     frontier_mask = (is_me & reach_opp & (dist_diff <= 1))
    
#     contested = np.sum(frontier_mask)
#     max_cd, min_cd = 0, dim * dim

#     if contested > 0:
#         f_dists = dist_me[frontier_mask]
#         max_cd = np.max(f_dists)
#         min_cd = np.min(f_dists)

#     # 4. Weighted Voronoi (Using Pre-computed global masks)
#     my_even  = cur_board.chicken_player.even_chicken
#     opp_even = cur_board.chicken_enemy.even_chicken

#     # Select correct mask without creating new array
#     parity_mask_me = _IS_EVEN if my_even else _IS_ODD
#     parity_mask_opp = _IS_EVEN if opp_even else _IS_ODD

#     my_voronoi = np.sum(_WEIGHTS[is_me & parity_mask_me])
#     opp_voronoi = np.sum(_WEIGHTS[is_opp & parity_mask_opp])

#     # 5. Directional Stats (Global grid arithmetic)
#     my_x, my_y = cur_board.chicken_player.get_location()
    
#     # Use globals relative to my position
#     dx = _X_GRID - my_x
#     dy = _Y_GRID - my_y

#     c_up    = np.sum(frontier_mask & (dy < 0))
#     c_down  = np.sum(frontier_mask & (dy > 0))
#     c_left  = np.sum(frontier_mask & (dx < 0))
#     c_right = np.sum(frontier_mask & (dx > 0))

#     # 6. Fragmentation
#     counts = np.array([c_left, c_right, c_up, c_down])
#     total = np.sum(counts)
    
#     frag_score = 0.0
#     if total > 1:
#         m = np.max(counts)
#         frag_score = 1.0 - (m / total)

#     return VoronoiInfo(
#         my_owned=int(my_owned),
#         opp_owned=int(opp_owned),
#         contested=int(contested),
#         max_contested_dist=int(max_cd),
#         min_contested_dist=int(min_cd),
#         my_voronoi=int(my_voronoi),
#         opp_voronoi=int(opp_voronoi),
#         vor_score=int(my_voronoi - opp_voronoi),
#         contested_up=int(c_up),
#         contested_right=int(c_right),
#         contested_down=int(c_down),
#         contested_left=int(c_left),
#         frag_score=float(frag_score),
#     )