#!/bin/bash
# Script to run a single game - used by SLURM job array
# Usage: run_single_game.sh <game_id> <opponent>

set -e

GAME_ID=$1
OPPONENT="${2:-Hikaru_3}"
AGENT_NAME="CPPHikaru_3"

# Get directory where script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

# Set library path
export LD_LIBRARY_PATH="${SCRIPT_DIR}/3600-agents/CPPHikaru_3:${LD_LIBRARY_PATH}"

# Create output directories
mkdir -p batch_results/game_logs
mkdir -p batch_results/depth_logs
mkdir -p batch_results/match_data

# Run single game
LOG_FILE="batch_results/game_logs/game_${GAME_ID}.log"
DEPTH_FILE="batch_results/depth_logs/game_${GAME_ID}_depth.log"
STDERR_FILE="batch_results/game_logs/game_${GAME_ID}_stderr.log"

cd engine
python3 run_local_agents.py "${AGENT_NAME}" "${OPPONENT}" \
    > "${SCRIPT_DIR}/${LOG_FILE}" 2> "${SCRIPT_DIR}/${STDERR_FILE}" || true

# Extract depth logs from stderr
grep "DEPTH_LOG" "${SCRIPT_DIR}/${STDERR_FILE}" > "${SCRIPT_DIR}/${DEPTH_FILE}" || touch "${SCRIPT_DIR}/${DEPTH_FILE}"

# Find the match JSON file created (most recent one)
MATCH_FILE=$(ls -t "${SCRIPT_DIR}/3600-agents/matches/${AGENT_NAME}_${OPPONENT}_"*.json 2>/dev/null | head -1 || true)

if [ -n "$MATCH_FILE" ]; then
    # Copy match file with game ID
    cp "$MATCH_FILE" "${SCRIPT_DIR}/batch_results/match_data/game_${GAME_ID}_match.json"
fi

echo "Game ${GAME_ID} completed"

